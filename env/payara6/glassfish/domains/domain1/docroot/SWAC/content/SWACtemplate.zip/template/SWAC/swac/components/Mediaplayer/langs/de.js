var Mediaplayer_de = {
    playlist: 'Playlist',
    play: 'Abspielen',
    prevtitle: 'Vorherigen Titel',
    nexttitle: 'Nächsten Titel',
    volume: 'Lautstaerke',
    mute: 'Stumm schalten',
    download: 'Aktuelles Medium herunterladen',
    sendcomment: 'Kommentar senden',
    closeoverlay: 'Fortsetzen'
};


