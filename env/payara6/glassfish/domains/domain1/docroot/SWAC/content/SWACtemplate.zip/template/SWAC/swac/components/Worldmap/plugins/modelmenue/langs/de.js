var Worldmap_modelmenue_de = {
    southview: "Südansicht",
    westview: "Westansicht",
    northview: "Nordansicht",
    eastview: "Ostansicht",
    favlinkcreate: 'Gebäudeansicht in den Lesezeichen speichern',
    showdetailmodel: 'Detailmodell anzeigen',
    favlink: 'Speichern Sie bitte folgenden Link in ihren Lesezeichen: <a href:"%url%">%url%</a>',
    startanimation: 'Um das Model laufen',
    stopanimation: 'Aufhören um das Model zu laufen',
    tostartview: 'Zurück zur Startansicht',
    close: 'Menü schließen',
    stepright: 'Nach rechts um das Gebäude gehen',
    stepleft: 'Nach links um das Gebäude gehen'
};