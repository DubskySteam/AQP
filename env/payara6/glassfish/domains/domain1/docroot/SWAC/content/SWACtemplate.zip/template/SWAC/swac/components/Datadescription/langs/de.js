var Datadescription_de = {
    legendtitle: "Legende",
    nodata: "Es sind keine Daten vorhanden.",
    attribution: "Quelle"
};


