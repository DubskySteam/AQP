var Edit_de = {
    noinputdef: "Es kann kein Eingabeformular generiert werden. Es wurde keine Eingabedefinition angegeben.",
    errorcreateform: "Fehler beim Erzeugen des Formulars.",
    forgotteninput: "Sie haben nicht alle erforderlichen Felder ausgef&uuml;llt.",
    noObjectTemplates: "Es sind keine möglichen Eintr&auml;ge definiert.",
    formlegend: "Datensatz bearbeiten",
    adddataset: "Neuen Datensatz anlegen",
    loadingeditform: "Bearbeitungsformular wird geladen",
    editor: "Editor",
    newdataset: "Neuer Datensatz",
    editdataset: "Datensatz bearbeiten",
    valuerequired: "Bitte geben Sie einen Wert für %attrname% ein.",
    noselection: "Keine Auswahl",
    drophere: "Hierher ziehen",
    dropNotAccepted: "Dieses Element kann hier nicht zugeordnet werden.",
    dropFetchError: "Die Daten des Elements konnten nicht abgerufen werden.",
    couldnotsave: "Die Eingaben können nicht gespeichert werden.",
    refDelete: "Verbindung löschen",
    save: "Speichern"
};


