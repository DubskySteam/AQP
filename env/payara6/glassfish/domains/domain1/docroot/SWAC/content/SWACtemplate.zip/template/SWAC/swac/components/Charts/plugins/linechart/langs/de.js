var chart_linechart_de = {
    name: "Liniendiagramm"
};


