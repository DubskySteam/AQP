var Navigation_de = {
    noroute : "Die gewünschte Seite ist nicht verfügbar. Entweder Sie haben nicht die benötigten Rechte oder die Seite existiert nicht."
};


