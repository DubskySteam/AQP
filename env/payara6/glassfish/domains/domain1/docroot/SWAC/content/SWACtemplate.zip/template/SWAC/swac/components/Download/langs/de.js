var Download_de = {
    downloadnow : 'Jetzt herunterladen',
    preview: 'Vorschau',
    title: 'Titel',
    link: 'Downloadlink'
};


