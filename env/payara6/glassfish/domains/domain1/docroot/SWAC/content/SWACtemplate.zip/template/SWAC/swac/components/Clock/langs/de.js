var Clock_de = {
};


