var Visualmodel_de = {
    visuelemcreator: "Elemente erzeugen",
    scenegraph: "Szene"
};


