var Mediacode_de = {
    notitle: 'Kein Titel',
    novideosupport: 'Ihr Browser unterstützt leider keine Videovidergabe.',
    noaudiosupport: 'Ihr Browser unterstützt leider keine Audiovidergabe',
    playlist: 'Playlist',
    play: 'Abspielen',
    prevtitle: 'Vorherigen Titel',
    nexttitle: 'Nächsten Titel',
    mute: 'Stumm schalten',
    download: 'Aktuelles Medium herunterladen',
    sendcomment: 'Kommentar senden',
    closeoverlay: 'Fortsetzen'
};


