var Comments_de = {
    newcomment: 'Neuer Kommentar',
    comment: 'Kommentar',
    newreply: 'Neue Antwort',
    showreplys: 'Antworten anzeigen',
    reply: 'Antwort',
    save: 'Kommentar speichern',
    forgotteninput: "Sie haben nicht alle erforderlichen Felder ausgef&uuml;llt.",
    couldnotsave: 'Der Kommentar konnte nicht gespeichert werden. Versuchen Sie es später noch einmal.'
};


