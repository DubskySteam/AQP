var mediaeditor_mediareference_de = {
    selectMediaForLinking : 'Wählen Sie jetzt ein Medium zum Verknüpfen aus.'
};


