var Mediaeditor_mediaanalysis_de = {
    start: 'Analyse starten',
    filterlogo: 'Logo filtern',
    threshold: 'Schwellwert',
    calcThreshold: 'automatisch bestimmen',
    tagging: 'Tags',
    analysiserror: 'Es ist ein Fehler bei der Analyse aufgetreten.'
};


