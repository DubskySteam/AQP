var chart_barchart_de = {
    name: "Balkendiagramm"
};


