var Mediaeditor_mediatags_de = {
    notags: 'Keine Markierungen vorhanden',
    notagsfailure: 'Die Markierungen konnten nicht geladen werden.',
    noadding: 'Es können keine neuen Markierungen angelegt werden, da keine Typen definiert wurden.',
    noaddingfailure: 'Es können keine neuen Markierungen angelegt werden, da die Typen nicht geladen werden konnten.',
    addtag: 'Markierung hinzuf&uuml;gen',
    wizzard: 'Markierungs-Assistent',
    wizzard1_draw: 'Markierung zeichnen',
    wizzard2_tag: 'Typ auswählen',
    nopolygoncreated: 'Bitte zeichnen Sie zuerst ein Polygon.',
    pleaseselect: 'Bitte auswählen',
    wizzard3_title: 'Titel',
    notagtypeselected: 'Sie müssen zuerst einen Typen auswählen',
    wizzard4_desc: 'Beschreibung',
    wizzardnext: 'Nächster Schritt',
    savetag: 'Markierung speichern',
    deltag: 'Markierung löschen',
    edittag: 'Markierung bearbeiten',
    notsavedtag: 'Diese Markierung wurde noch nicht gespeichert'
};


