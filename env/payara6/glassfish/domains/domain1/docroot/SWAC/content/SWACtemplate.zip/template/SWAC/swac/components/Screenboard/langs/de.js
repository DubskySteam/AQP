var Screenboard_de = {
    nofunction: 'Diesem Button ist keine Funktion zugeordnet.'
};


