var Search_de = {
    running: 'Suche läuft...',
    nothingfound: 'Es wurde nichts gefunden',
    searcherror: 'Es ist ein Fehler aufgetreten',
    searchtoless: 'Bitte geben Sie mindestens %d% Zeichen ein.',
    gotoresult: 'Ergebnis anzeigen',
    indexsearch: 'Suche nach Anfangsbuchstaben',
    performingIndexSearch: 'Rufe Indexdaten ab...',
    indexSearcherror: 'Fehler beim Abruf der Indexdaten.'
};


