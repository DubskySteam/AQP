var Visualise_de = {
  state: "Stand: ",
  clock: "Uhr",
  thermometer: "Temperatur",
  hygrometer: "Luftfeuchtigkeit"
};