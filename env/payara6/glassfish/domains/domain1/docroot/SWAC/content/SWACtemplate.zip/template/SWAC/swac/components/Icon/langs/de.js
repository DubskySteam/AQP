var Icon_de = {
    noIconFor: 'Es gibt kein Icon für %iconSearchExpression%'
};


