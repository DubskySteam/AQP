/* 
 * Local Storage accessor for SWAC components
 */

SWAC_storage = {};

SWAC_storage.files = {};

