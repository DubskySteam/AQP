var Lookscreen_de = {
    locknow: "Bildschirm jetzt sperren",
    lockmessage: "Bitte tippen oder klicken Sie auf den Bildschirm um die Eingabe freizuschalten."
};


