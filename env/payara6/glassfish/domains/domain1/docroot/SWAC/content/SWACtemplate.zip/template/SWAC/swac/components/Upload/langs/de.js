var Upload_de = {
    selectfile: "Ziehen Sie sie eine oder mehrere Dateien per Drag & Drop hierher",
    draganddropfile: "oder wählen Sie hier eine aus.",
    toupload: 'Wurde hochgeladen',
    uploaded: 'Wird hochgeladen',
    saved: 'Wurde gespeichert',
    notsaved: 'Wurde nicht gespeichert',
    preuploaderror: 'Es gab einen Fehler beim Vorbereiten des Uploads',
    addatamissing: 'Es fehlen Eingaben im Formular',
    noprocessoravailable: "Es steht kein Parser für diese Datei zur Verfügung",
    canbeprocessedby: 'Wählen Sie einen Parser zur Interpretation dieser Datei:',
    startprocessing: 'Verarbeitung starten',
    processed: 'Wurde verarbeitet',
    processingFailed: 'Verarbeitung fehlgeschlagen',
    processingSuccseed: 'Verarbeitung erfolgreich',
    notprocessed: 'Die Datei konnte nicht verarbeitet werden.',
    erroroccured: 'Es ist ein Fehler aufgetreten'
};


