var Visualmodel_visucreator_de = {
    elements: "Elemente",
    connectors: "Verbinder",
    clear_desc: "Entfernt alle Elemente",
    removeelem_desc: "Entfernt das ausgewaehlte Element",
    removeelem_nonsel: "Bitte wählen Sie zuerst das zu löschende Element aus.",
    addelem_desc: "Ein Element hinzufügen",
    addedelem: "Neues Element",
    copyelem_desc: "Ein Element kopieren",
    copyelem_nonsel: "Bitte wählen Sie zuerst das Element, das sie kopieren möchten aus.",
    copytitle: "Kopie",
    addcon_desc: "Eine Verbindung hinzufügen",
    addcon_nonsel: "Bitte wählen Sie zuerst das Ausgangselement aus, von dem Sie eine Verbindung erstellen möchten.",
    addcon_selpart2: "Bitte wählen Sie nun den zweiten Partner der Verbinung aus."
};


