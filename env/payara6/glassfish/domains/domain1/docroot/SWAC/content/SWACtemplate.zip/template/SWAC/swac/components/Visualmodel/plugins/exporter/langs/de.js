var Visualmodel_exporter_de = {
    save: "Speichern",
    save_asimage: "Als Bild"
};


