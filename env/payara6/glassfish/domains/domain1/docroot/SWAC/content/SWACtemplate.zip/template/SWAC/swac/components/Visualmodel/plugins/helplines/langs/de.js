var Visualmodel_helplines_de = {
    save: "Speichern",
    save_asimage: "Als Bild"
};


