var Guide_de = {
};


