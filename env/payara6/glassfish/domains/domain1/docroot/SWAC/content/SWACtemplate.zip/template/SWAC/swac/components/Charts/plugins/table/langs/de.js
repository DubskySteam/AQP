var chart_table_de = {
    name: "Tabelle"
};


