var Mediaeditor_de = {
    mediatype_unsupported: 'Der Medientyp %mimetype% wird leider nicht unterstützt'
};


