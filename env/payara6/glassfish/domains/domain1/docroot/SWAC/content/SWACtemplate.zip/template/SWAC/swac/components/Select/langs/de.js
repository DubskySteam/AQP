var Select_de = {
    nodata : 'Es gibt nichts zum auswählen',
    noselection : 'Keine Auswahl',
    loadSubs : '%availSets% laden',
    loadMore : 'Weitere laden',
    expandSubSources : '',
    notexpandable: 'Unterdatensätze können nicht geladen werden.'
};