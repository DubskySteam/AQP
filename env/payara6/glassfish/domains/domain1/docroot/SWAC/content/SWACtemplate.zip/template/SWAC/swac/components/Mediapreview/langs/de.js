var Mediapreview_de = {
    notitle: 'Bild ohne Titel',
    novideosupport: 'Ihr Browser unterstützt keine Videos.',
    filternone: 'Alle anzeigen',
    filterwithout: 'Ohne diesem',
    edit: 'bearbeiten',
    couldnotgetfull: 'Das Medium konnte nicht geladen werden.'
};


