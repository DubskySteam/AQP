var chart_oiechart_de = {
    name: "Tortendiagramm"
};


