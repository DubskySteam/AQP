var Worldmap_de = {
    errorloadingmodel: "Das Model konnte leider nicht geladen werden",
    modelnotfound: "Das Model konnte nicht gefunden werden.",
    no_model: "Zu diesem Gebäude ist kein Model verfügbar.",
    no_grounddata: "Zu diesem Gebäude sind keine Adressdaten verfügbar.",
    value: "Wert",
    datafrom: "Daten vom",
    setid: "Datensatz Nr.",
    lat: "Latitude",
    lon: "Longitude",
    height: "Höhe"
};