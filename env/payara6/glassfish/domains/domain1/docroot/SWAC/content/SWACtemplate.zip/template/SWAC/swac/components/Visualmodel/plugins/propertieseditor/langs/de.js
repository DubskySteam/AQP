var Visualmodel_propertieseditor_de = {
    propertieseditor: "Eigenschaften editieren",
    novisuelemfocus: "Wählen Sie ein Element um hier etwas zu sehen",
    properties_name: "Name",
    properties_desc: "Beschreibung",
    properties_fillcolor: "Füllfarbe",
    properties_bordercolor: "Rahmenfarbe",
    properties_position: "Position",
    properties_size: "Größe",
    properties_show: "Anzeigen"
};


