var User_de = {
    login: 'Login',
    enterlogindata: 'Bitte geben Sie ihre Zugangsdaten ein.',
    username: 'Benutzername',
    userpwd: 'Password',
    loginprogress: 'Bitte haben Sie einen Moment Geduld, Sie werden eingeloggt.',
    nologinpossible: 'Der Login ist derzeit nicht möglich.',
    logout: 'Logout',
    registerhere: 'Noch kein Konto? Hier anmelden.'
};


