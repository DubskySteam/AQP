/**
 * Tests for select component
 */

let swactest_select = {};
swactest_select.templates = [];
swactest_select.templates[0] = "";

swactest_select.onSelectOneFromSelectBox = function() {
    
};

swactest_select.onSelectTwoFromMultipleSelectBox = function() {
    
};

swactest_select.onSelectOneFromCheckboxes = function() {
    
};

swactest_select.onSelectTwoFromCheckboxes = function() {
    
};